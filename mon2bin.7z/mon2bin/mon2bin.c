/*
 * Convert binary file to Woz monitor format.
 * mon2bin myprog.mon
 *
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* print command usage */
void usage(char *name) {
    fprintf(stderr, "usage: %s [-h] <Filename>\n", name);
}

/* Show help info */
void showHelp(char *name)
{
    usage(name);
    fprintf(stderr,
            "\n-h  Show help info and exit.\n"
	    "\n");
}

int main(int argc, char *argv[])
{

int opt;

#define isHexDigit(c) ((c >= '0' && c <= '9') || ((c & 0x5F) >= 'A' && (c & 0x5F) <= 'F'))

static unsigned char step, type;
static unsigned short max, start;
static char filename[1024], buffer[1024];
//static int choice;
static FILE *fd, *fdout;

unsigned int i, length, size;
unsigned short address;
unsigned char value;
//unsigned char *fbrut;

//unsigned int i, j, k, length;
//unsigned short end, temp;
//char *strFile;


    while ((opt = getopt(argc, argv, "hv12fl:r:b:c:")) != -1) {
        switch (opt) {

        case 'h':
            showHelp(argv[0]);
            exit(EXIT_SUCCESS);
        default:
            usage(argv[0]);
            exit(EXIT_FAILURE);
        }
    }

    if (argc != optind + 1) {
        usage(argv[0]);
        exit(EXIT_FAILURE);
    }

    fd = fopen(argv[optind], "rb");

	strcpy(filename,argv[optind]); 
	i=strlen(filename); while (filename[i]!='.') i--;
	filename[i]=0;    	       
	strcat(filename,".bin");
	
    fdout = fopen(filename, "wb");
		
    if (fd == NULL) {
        fprintf(stderr, "%s: Unable to open '%s'\n", argv[0], argv[optind]);
        return 1;
    }

			while (!feof(fd))
			{
				if (!fgets(buffer, 1024, fd))
					continue;
				
				//fprintf(stderr, "buffer[0]= %d\n", buffer[0]);
				if (buffer[0] == '/' || buffer[0] == '\r' || buffer[0] == '\n')
					continue;

				if (buffer[0] != ':')
				{
					if (isHexDigit(buffer[0]))
					{
						if (buffer[1] == ':')
							i = 2;
						else if (isHexDigit(buffer[1]))
						{
							if (buffer[2] == ':')
								i = 3;
							else if (isHexDigit(buffer[2]))
							{
								if (buffer[3] == ':')
									i = 4;
								else if (isHexDigit(buffer[3]))
								{
									if (buffer[4] == ':')
										i = 5;
									else
										continue;
								}
								else
									continue;
							}
							else
								continue;
						}
						else
							continue;
					}
					else
						continue;

					sscanf(buffer, "%4X", &address);

					if (buffer[i] == ' ')
						i++;
				}
				else if (buffer[1] == ' ')
					i = 2;
				else
					i = 1;
					
				length = strlen(buffer); // lee una l�nea

				//int j; for (j=0; j< length; j++) {printf("%2X ",buffer[j]);printf("\n");}  	    		
				for (; i < length; i += 3)
				{
					if (buffer[i]=='\r' || buffer[i] == '\n') continue; // quitar 0x0D y 0x0A
					sscanf(&buffer[i], "%2X", &value);
					//memWrite(address++, value);
				//	  printf("\n\n");printf("%d\n",i);
				//	  printf("%2X %d\n", value,value);
					fprintf(fdout,"%c", value);
				}
			}

	fclose(fd);

	fclose(fdout);


    return 0;
}

