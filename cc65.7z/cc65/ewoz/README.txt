This is the source code EWoz, an extended version of the Woz Monitor for the Apple 1.

See http://www.brielcomputers.com/phpBB3/viewtopic.php?f=9&t=197#p888

Note that it performs i/o using the serial port on the Multi Port I/O
board for the Briel Replica 1.

It is intended to be assembled with CC65 (See http://www.cc65.org).
