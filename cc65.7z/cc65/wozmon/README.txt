This is the source code for the original Woz Monitor for the Apple 1.
It is intended to be assembled with CC65 (See http://www.cc65.org).

The Replica 1 uses a slightly modified version as part of the Krusader
assembler. See
http://school.anhb.uwa.edu.au/personalpages/kwessen/apple1/Krusader.htm

An enhanced version of the Woz Monitor called EWoz can be found at
http://www.brielcomputers.com/phpBB3/viewtopic.php?f=9&t=197
or https://gist.github.com/2760560
